﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000014 RID: 20
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060000F0 RID: 240 RVA: 0x0000608C File Offset: 0x0000428C
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("platformCore.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__01A4D5BB6C89A318578709D428954061A84197218D75B9E6AF9C69D6ED631E9E = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "01A4D5BB6C89A318578709D428954061A84197218D75B9E6AF9C69D6ED631E9E");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E07328CBF6853FF6578386FE4A98676B2A3AAE16A1630B716869FA01CC3500C9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "E07328CBF6853FF6578386FE4A98676B2A3AAE16A1630B716869FA01CC3500C9");
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x000028E9 File Offset: 0x00000AE9
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x17000045 RID: 69
	// (get) Token: 0x060000F2 RID: 242 RVA: 0x000060DC File Offset: 0x000042DC
	// (set) Token: 0x060000F3 RID: 243 RVA: 0x000028F2 File Offset: 0x00000AF2
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _01A4D5BB6C89A318578709D428954061A84197218D75B9E6AF9C69D6ED631E9E
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__01A4D5BB6C89A318578709D428954061A84197218D75B9E6AF9C69D6ED631E9E, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__01A4D5BB6C89A318578709D428954061A84197218D75B9E6AF9C69D6ED631E9E, (void*)(&value));
		}
	}

	// Token: 0x17000046 RID: 70
	// (get) Token: 0x060000F4 RID: 244 RVA: 0x000060F8 File Offset: 0x000042F8
	// (set) Token: 0x060000F5 RID: 245 RVA: 0x00002900 File Offset: 0x00000B00
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 E07328CBF6853FF6578386FE4A98676B2A3AAE16A1630B716869FA01CC3500C9
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E07328CBF6853FF6578386FE4A98676B2A3AAE16A1630B716869FA01CC3500C9, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E07328CBF6853FF6578386FE4A98676B2A3AAE16A1630B716869FA01CC3500C9, (void*)(&value));
		}
	}

	// Token: 0x0400008E RID: 142
	private static readonly IntPtr NativeFieldInfoPtr__01A4D5BB6C89A318578709D428954061A84197218D75B9E6AF9C69D6ED631E9E;

	// Token: 0x0400008F RID: 143
	private static readonly IntPtr NativeFieldInfoPtr_E07328CBF6853FF6578386FE4A98676B2A3AAE16A1630B716869FA01CC3500C9;

	// Token: 0x02000025 RID: 37
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=680")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060001F5 RID: 501 RVA: 0x0000318E File Offset: 0x0000138E
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=680");
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x000031A4 File Offset: 0x000013A4
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000026 RID: 38
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=943")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060001F7 RID: 503 RVA: 0x000031B6 File Offset: 0x000013B6
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=943");
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x000031CC File Offset: 0x000013CC
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x0200002A RID: 42
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x06000364 RID: 868 RVA: 0x00013404 File Offset: 0x00011604
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Unity.Addressables.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__665ECC1C05160C0F32D3061E27307CCD620C172A96858BE3F9B40764886531FC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "665ECC1C05160C0F32D3061E27307CCD620C172A96858BE3F9B40764886531FC");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__915F098662DB855AFE64CBFACF6839FC652CED0140B9FFA733C3BDEBD84E36E7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "915F098662DB855AFE64CBFACF6839FC652CED0140B9FFA733C3BDEBD84E36E7");
	}

	// Token: 0x06000365 RID: 869 RVA: 0x000032D6 File Offset: 0x000014D6
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x170000EB RID: 235
	// (get) Token: 0x06000366 RID: 870 RVA: 0x00013454 File Offset: 0x00011654
	// (set) Token: 0x06000367 RID: 871 RVA: 0x000032DF File Offset: 0x000014DF
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _665ECC1C05160C0F32D3061E27307CCD620C172A96858BE3F9B40764886531FC
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__665ECC1C05160C0F32D3061E27307CCD620C172A96858BE3F9B40764886531FC, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__665ECC1C05160C0F32D3061E27307CCD620C172A96858BE3F9B40764886531FC, (void*)(&value));
		}
	}

	// Token: 0x170000EC RID: 236
	// (get) Token: 0x06000368 RID: 872 RVA: 0x00013470 File Offset: 0x00011670
	// (set) Token: 0x06000369 RID: 873 RVA: 0x000032ED File Offset: 0x000014ED
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _915F098662DB855AFE64CBFACF6839FC652CED0140B9FFA733C3BDEBD84E36E7
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__915F098662DB855AFE64CBFACF6839FC652CED0140B9FFA733C3BDEBD84E36E7, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__915F098662DB855AFE64CBFACF6839FC652CED0140B9FFA733C3BDEBD84E36E7, (void*)(&value));
		}
	}

	// Token: 0x04000294 RID: 660
	private static readonly IntPtr NativeFieldInfoPtr__665ECC1C05160C0F32D3061E27307CCD620C172A96858BE3F9B40764886531FC;

	// Token: 0x04000295 RID: 661
	private static readonly IntPtr NativeFieldInfoPtr__915F098662DB855AFE64CBFACF6839FC652CED0140B9FFA733C3BDEBD84E36E7;

	// Token: 0x02000085 RID: 133
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=2589")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x0600059B RID: 1435 RVA: 0x00004669 File Offset: 0x00002869
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=2589");
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x0000467F File Offset: 0x0000287F
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000086 RID: 134
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=2943")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x0600059D RID: 1437 RVA: 0x00004691 File Offset: 0x00002891
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=2943");
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x000046A7 File Offset: 0x000028A7
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

﻿using System;
using System.Reflection;
using System.Runtime.Versioning;

[assembly: AssemblyAlgorithmId(0)]
[assembly: AssemblyVersion("4.0.5.0")]

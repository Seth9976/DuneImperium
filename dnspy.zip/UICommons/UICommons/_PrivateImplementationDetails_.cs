﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000007 RID: 7
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x0600006F RID: 111 RVA: 0x000040B0 File Offset: 0x000022B0
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("UICommons.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__097EE748252BB7AB32A9448F73ABDB5171DD80B55E7E3F79D1D73E4480395885 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "097EE748252BB7AB32A9448F73ABDB5171DD80B55E7E3F79D1D73E4480395885");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__758570B23856C2171E5173D16A478952B1A50F72AB833F0A619D8FA2D2754C65 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "758570B23856C2171E5173D16A478952B1A50F72AB833F0A619D8FA2D2754C65");
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00002231 File Offset: 0x00000431
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000071 RID: 113 RVA: 0x00004100 File Offset: 0x00002300
	// (set) Token: 0x06000072 RID: 114 RVA: 0x0000223A File Offset: 0x0000043A
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _097EE748252BB7AB32A9448F73ABDB5171DD80B55E7E3F79D1D73E4480395885
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__097EE748252BB7AB32A9448F73ABDB5171DD80B55E7E3F79D1D73E4480395885, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__097EE748252BB7AB32A9448F73ABDB5171DD80B55E7E3F79D1D73E4480395885, (void*)(&value));
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000073 RID: 115 RVA: 0x0000411C File Offset: 0x0000231C
	// (set) Token: 0x06000074 RID: 116 RVA: 0x00002248 File Offset: 0x00000448
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _758570B23856C2171E5173D16A478952B1A50F72AB833F0A619D8FA2D2754C65
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__758570B23856C2171E5173D16A478952B1A50F72AB833F0A619D8FA2D2754C65, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__758570B23856C2171E5173D16A478952B1A50F72AB833F0A619D8FA2D2754C65, (void*)(&value));
		}
	}

	// Token: 0x04000055 RID: 85
	private static readonly IntPtr NativeFieldInfoPtr__097EE748252BB7AB32A9448F73ABDB5171DD80B55E7E3F79D1D73E4480395885;

	// Token: 0x04000056 RID: 86
	private static readonly IntPtr NativeFieldInfoPtr__758570B23856C2171E5173D16A478952B1A50F72AB833F0A619D8FA2D2754C65;

	// Token: 0x0200000B RID: 11
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=156")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060000AD RID: 173 RVA: 0x00002412 File Offset: 0x00000612
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=156");
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00002428 File Offset: 0x00000628
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200000C RID: 12
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=272")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060000AF RID: 175 RVA: 0x0000243A File Offset: 0x0000063A
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=272");
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00002450 File Offset: 0x00000650
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

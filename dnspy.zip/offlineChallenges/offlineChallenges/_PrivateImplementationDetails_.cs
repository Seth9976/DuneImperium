﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000015 RID: 21
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060000DA RID: 218 RVA: 0x00005748 File Offset: 0x00003948
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("offlineChallenges.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__4DEE222C798EFB4F9764F8CC5A3C92F55A7C11565EBD26CAD990426977DB1312 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "4DEE222C798EFB4F9764F8CC5A3C92F55A7C11565EBD26CAD990426977DB1312");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__9EC62F7E333EAFA26B6CC3B34F55C4063C5968852B07BEB1242249BB5A09D829 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "9EC62F7E333EAFA26B6CC3B34F55C4063C5968852B07BEB1242249BB5A09D829");
	}

	// Token: 0x060000DB RID: 219 RVA: 0x0000262D File Offset: 0x0000082D
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x060000DC RID: 220 RVA: 0x00005798 File Offset: 0x00003998
	// (set) Token: 0x060000DD RID: 221 RVA: 0x00002636 File Offset: 0x00000836
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _4DEE222C798EFB4F9764F8CC5A3C92F55A7C11565EBD26CAD990426977DB1312
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__4DEE222C798EFB4F9764F8CC5A3C92F55A7C11565EBD26CAD990426977DB1312, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__4DEE222C798EFB4F9764F8CC5A3C92F55A7C11565EBD26CAD990426977DB1312, (void*)(&value));
		}
	}

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x060000DE RID: 222 RVA: 0x000057B4 File Offset: 0x000039B4
	// (set) Token: 0x060000DF RID: 223 RVA: 0x00002644 File Offset: 0x00000844
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _9EC62F7E333EAFA26B6CC3B34F55C4063C5968852B07BEB1242249BB5A09D829
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__9EC62F7E333EAFA26B6CC3B34F55C4063C5968852B07BEB1242249BB5A09D829, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__9EC62F7E333EAFA26B6CC3B34F55C4063C5968852B07BEB1242249BB5A09D829, (void*)(&value));
		}
	}

	// Token: 0x0400008D RID: 141
	private static readonly IntPtr NativeFieldInfoPtr__4DEE222C798EFB4F9764F8CC5A3C92F55A7C11565EBD26CAD990426977DB1312;

	// Token: 0x0400008E RID: 142
	private static readonly IntPtr NativeFieldInfoPtr__9EC62F7E333EAFA26B6CC3B34F55C4063C5968852B07BEB1242249BB5A09D829;

	// Token: 0x0200001C RID: 28
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=877")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x06000123 RID: 291 RVA: 0x00002824 File Offset: 0x00000A24
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=877");
		}

		// Token: 0x06000124 RID: 292 RVA: 0x0000283A File Offset: 0x00000A3A
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200001D RID: 29
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=1006")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x06000125 RID: 293 RVA: 0x0000284C File Offset: 0x00000A4C
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=1006");
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00002862 File Offset: 0x00000A62
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

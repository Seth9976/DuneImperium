﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000008 RID: 8
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x0600003A RID: 58 RVA: 0x00002F80 File Offset: 0x00001180
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("test.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__2A55F5DEB1D2B6063AEE537CF7CD23B198718EBCD0CF1B4CAF170AEDDCC855BA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "2A55F5DEB1D2B6063AEE537CF7CD23B198718EBCD0CF1B4CAF170AEDDCC855BA");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6D4F8F47A05AC4F38FC4203AA94CC8C7D62BA12F0DEEB32585011E8CB73E71D6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "6D4F8F47A05AC4F38FC4203AA94CC8C7D62BA12F0DEEB32585011E8CB73E71D6");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B109F1B74A2D3FDDBF48EC87FD6D66023E12A8ACCFA00B8729B1D08940F3D786 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "B109F1B74A2D3FDDBF48EC87FD6D66023E12A8ACCFA00B8729B1D08940F3D786");
	}

	// Token: 0x0600003B RID: 59 RVA: 0x000021CC File Offset: 0x000003CC
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600003C RID: 60 RVA: 0x00002FE4 File Offset: 0x000011E4
	// (set) Token: 0x0600003D RID: 61 RVA: 0x000021D5 File Offset: 0x000003D5
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 _2A55F5DEB1D2B6063AEE537CF7CD23B198718EBCD0CF1B4CAF170AEDDCC855BA
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__2A55F5DEB1D2B6063AEE537CF7CD23B198718EBCD0CF1B4CAF170AEDDCC855BA, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__2A55F5DEB1D2B6063AEE537CF7CD23B198718EBCD0CF1B4CAF170AEDDCC855BA, (void*)(&value));
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600003E RID: 62 RVA: 0x00003000 File Offset: 0x00001200
	// (set) Token: 0x0600003F RID: 63 RVA: 0x000021E3 File Offset: 0x000003E3
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _6D4F8F47A05AC4F38FC4203AA94CC8C7D62BA12F0DEEB32585011E8CB73E71D6
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6D4F8F47A05AC4F38FC4203AA94CC8C7D62BA12F0DEEB32585011E8CB73E71D6, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6D4F8F47A05AC4F38FC4203AA94CC8C7D62BA12F0DEEB32585011E8CB73E71D6, (void*)(&value));
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x06000040 RID: 64 RVA: 0x0000301C File Offset: 0x0000121C
	// (set) Token: 0x06000041 RID: 65 RVA: 0x000021F1 File Offset: 0x000003F1
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 B109F1B74A2D3FDDBF48EC87FD6D66023E12A8ACCFA00B8729B1D08940F3D786
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B109F1B74A2D3FDDBF48EC87FD6D66023E12A8ACCFA00B8729B1D08940F3D786, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B109F1B74A2D3FDDBF48EC87FD6D66023E12A8ACCFA00B8729B1D08940F3D786, (void*)(&value));
		}
	}

	// Token: 0x04000022 RID: 34
	private static readonly IntPtr NativeFieldInfoPtr__2A55F5DEB1D2B6063AEE537CF7CD23B198718EBCD0CF1B4CAF170AEDDCC855BA;

	// Token: 0x04000023 RID: 35
	private static readonly IntPtr NativeFieldInfoPtr__6D4F8F47A05AC4F38FC4203AA94CC8C7D62BA12F0DEEB32585011E8CB73E71D6;

	// Token: 0x04000024 RID: 36
	private static readonly IntPtr NativeFieldInfoPtr_B109F1B74A2D3FDDBF48EC87FD6D66023E12A8ACCFA00B8729B1D08940F3D786;

	// Token: 0x0200000F RID: 15
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=16")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x06000061 RID: 97 RVA: 0x0000232B File Offset: 0x0000052B
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=16");
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00002341 File Offset: 0x00000541
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000010 RID: 16
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=298")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x06000063 RID: 99 RVA: 0x00002353 File Offset: 0x00000553
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=298");
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00002369 File Offset: 0x00000569
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000011 RID: 17
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=362")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed2
	{
		// Token: 0x06000065 RID: 101 RVA: 0x0000237B File Offset: 0x0000057B
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed2()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=362");
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00002391 File Offset: 0x00000591
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr, ref this));
		}
	}
}

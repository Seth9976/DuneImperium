﻿using System;

namespace Unity.Burst
{
	// Token: 0x0200000F RID: 15
	public enum BurstExecutionEnvironment
	{
		// Token: 0x0400011B RID: 283
		Default,
		// Token: 0x0400011C RID: 284
		NonDeterministic = 0,
		// Token: 0x0400011D RID: 285
		Deterministic
	}
}

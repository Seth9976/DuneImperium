﻿using System;

namespace Unity.Burst
{
	// Token: 0x02000006 RID: 6
	public enum FloatMode
	{
		// Token: 0x0400000C RID: 12
		Default,
		// Token: 0x0400000D RID: 13
		Strict,
		// Token: 0x0400000E RID: 14
		Deterministic,
		// Token: 0x0400000F RID: 15
		Fast
	}
}

﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000029 RID: 41
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060002A0 RID: 672 RVA: 0x0000E1C8 File Offset: 0x0000C3C8
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Unity.Burst.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__18DEC2780C55CB9A28CFC322874C570E2EAF1C4618EAB8DFA0FC662098626154 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "18DEC2780C55CB9A28CFC322874C570E2EAF1C4618EAB8DFA0FC662098626154");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6AC12597E10FFB084DEE014EEBFD52580EB845FD6B5CCA643AEAC527F7B02F2A = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "6AC12597E10FFB084DEE014EEBFD52580EB845FD6B5CCA643AEAC527F7B02F2A");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__80E69247CBC7E738ECDB10A5DCF3EF62BB27B3AB61C6ECF146B2C57CEFFB212F = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "80E69247CBC7E738ECDB10A5DCF3EF62BB27B3AB61C6ECF146B2C57CEFFB212F");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A199F717FBA4D1378A33D65E9660E45ADC176876A3450BACF2A80DA985FBDF14 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "A199F717FBA4D1378A33D65E9660E45ADC176876A3450BACF2A80DA985FBDF14");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B6EEE9EB277AC8DB2549A0E3B7076938FD9BD5E0DA706181BE7DC82CC7D88B4D = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "B6EEE9EB277AC8DB2549A0E3B7076938FD9BD5E0DA706181BE7DC82CC7D88B4D");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E");
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x00002E64 File Offset: 0x00001064
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x170000CE RID: 206
	// (get) Token: 0x060002A2 RID: 674 RVA: 0x0000E2A4 File Offset: 0x0000C4A4
	// (set) Token: 0x060002A3 RID: 675 RVA: 0x00002E6D File Offset: 0x0000106D
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 _07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA, (void*)(&value));
		}
	}

	// Token: 0x170000CF RID: 207
	// (get) Token: 0x060002A4 RID: 676 RVA: 0x0000E2C0 File Offset: 0x0000C4C0
	// (set) Token: 0x060002A5 RID: 677 RVA: 0x00002E7B File Offset: 0x0000107B
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 _18DEC2780C55CB9A28CFC322874C570E2EAF1C4618EAB8DFA0FC662098626154
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__18DEC2780C55CB9A28CFC322874C570E2EAF1C4618EAB8DFA0FC662098626154, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__18DEC2780C55CB9A28CFC322874C570E2EAF1C4618EAB8DFA0FC662098626154, (void*)(&value));
		}
	}

	// Token: 0x170000D0 RID: 208
	// (get) Token: 0x060002A6 RID: 678 RVA: 0x0000E2DC File Offset: 0x0000C4DC
	// (set) Token: 0x060002A7 RID: 679 RVA: 0x00002E89 File Offset: 0x00001089
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 _6AC12597E10FFB084DEE014EEBFD52580EB845FD6B5CCA643AEAC527F7B02F2A
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6AC12597E10FFB084DEE014EEBFD52580EB845FD6B5CCA643AEAC527F7B02F2A, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6AC12597E10FFB084DEE014EEBFD52580EB845FD6B5CCA643AEAC527F7B02F2A, (void*)(&value));
		}
	}

	// Token: 0x170000D1 RID: 209
	// (get) Token: 0x060002A8 RID: 680 RVA: 0x0000E2F8 File Offset: 0x0000C4F8
	// (set) Token: 0x060002A9 RID: 681 RVA: 0x00002E97 File Offset: 0x00001097
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 _80E69247CBC7E738ECDB10A5DCF3EF62BB27B3AB61C6ECF146B2C57CEFFB212F
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__80E69247CBC7E738ECDB10A5DCF3EF62BB27B3AB61C6ECF146B2C57CEFFB212F, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__80E69247CBC7E738ECDB10A5DCF3EF62BB27B3AB61C6ECF146B2C57CEFFB212F, (void*)(&value));
		}
	}

	// Token: 0x170000D2 RID: 210
	// (get) Token: 0x060002AA RID: 682 RVA: 0x0000E314 File Offset: 0x0000C514
	// (set) Token: 0x060002AB RID: 683 RVA: 0x00002EA5 File Offset: 0x000010A5
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 A199F717FBA4D1378A33D65E9660E45ADC176876A3450BACF2A80DA985FBDF14
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A199F717FBA4D1378A33D65E9660E45ADC176876A3450BACF2A80DA985FBDF14, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A199F717FBA4D1378A33D65E9660E45ADC176876A3450BACF2A80DA985FBDF14, (void*)(&value));
		}
	}

	// Token: 0x170000D3 RID: 211
	// (get) Token: 0x060002AC RID: 684 RVA: 0x0000E330 File Offset: 0x0000C530
	// (set) Token: 0x060002AD RID: 685 RVA: 0x00002EB3 File Offset: 0x000010B3
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6 B6EEE9EB277AC8DB2549A0E3B7076938FD9BD5E0DA706181BE7DC82CC7D88B4D
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B6EEE9EB277AC8DB2549A0E3B7076938FD9BD5E0DA706181BE7DC82CC7D88B4D, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B6EEE9EB277AC8DB2549A0E3B7076938FD9BD5E0DA706181BE7DC82CC7D88B4D, (void*)(&value));
		}
	}

	// Token: 0x170000D4 RID: 212
	// (get) Token: 0x060002AE RID: 686 RVA: 0x0000E34C File Offset: 0x0000C54C
	// (set) Token: 0x060002AF RID: 687 RVA: 0x00002EC1 File Offset: 0x000010C1
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C, (void*)(&value));
		}
	}

	// Token: 0x170000D5 RID: 213
	// (get) Token: 0x060002B0 RID: 688 RVA: 0x0000E368 File Offset: 0x0000C568
	// (set) Token: 0x060002B1 RID: 689 RVA: 0x00002ECF File Offset: 0x000010CF
	public unsafe static long D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010
	{
		get
		{
			long num;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010, (void*)(&num));
			return num;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010, (void*)(&value));
		}
	}

	// Token: 0x170000D6 RID: 214
	// (get) Token: 0x060002B2 RID: 690 RVA: 0x0000E384 File Offset: 0x0000C584
	// (set) Token: 0x060002B3 RID: 691 RVA: 0x00002EDD File Offset: 0x000010DD
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E, (void*)(&value));
		}
	}

	// Token: 0x0400045B RID: 1115
	private static readonly IntPtr NativeFieldInfoPtr__07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA;

	// Token: 0x0400045C RID: 1116
	private static readonly IntPtr NativeFieldInfoPtr__18DEC2780C55CB9A28CFC322874C570E2EAF1C4618EAB8DFA0FC662098626154;

	// Token: 0x0400045D RID: 1117
	private static readonly IntPtr NativeFieldInfoPtr__6AC12597E10FFB084DEE014EEBFD52580EB845FD6B5CCA643AEAC527F7B02F2A;

	// Token: 0x0400045E RID: 1118
	private static readonly IntPtr NativeFieldInfoPtr__80E69247CBC7E738ECDB10A5DCF3EF62BB27B3AB61C6ECF146B2C57CEFFB212F;

	// Token: 0x0400045F RID: 1119
	private static readonly IntPtr NativeFieldInfoPtr_A199F717FBA4D1378A33D65E9660E45ADC176876A3450BACF2A80DA985FBDF14;

	// Token: 0x04000460 RID: 1120
	private static readonly IntPtr NativeFieldInfoPtr_B6EEE9EB277AC8DB2549A0E3B7076938FD9BD5E0DA706181BE7DC82CC7D88B4D;

	// Token: 0x04000461 RID: 1121
	private static readonly IntPtr NativeFieldInfoPtr_C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C;

	// Token: 0x04000462 RID: 1122
	private static readonly IntPtr NativeFieldInfoPtr_D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010;

	// Token: 0x04000463 RID: 1123
	private static readonly IntPtr NativeFieldInfoPtr_D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E;

	// Token: 0x02000060 RID: 96
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=3")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x0600101F RID: 4127 RVA: 0x000032C7 File Offset: 0x000014C7
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=3");
		}

		// Token: 0x06001020 RID: 4128 RVA: 0x000032DD File Offset: 0x000014DD
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000061 RID: 97
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=32")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x06001021 RID: 4129 RVA: 0x000032EF File Offset: 0x000014EF
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=32");
		}

		// Token: 0x06001022 RID: 4130 RVA: 0x00003305 File Offset: 0x00001505
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000062 RID: 98
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=256")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed2
	{
		// Token: 0x06001023 RID: 4131 RVA: 0x00003317 File Offset: 0x00001517
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed2()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=256");
		}

		// Token: 0x06001024 RID: 4132 RVA: 0x0000332D File Offset: 0x0000152D
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000063 RID: 99
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=512")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed3
	{
		// Token: 0x06001025 RID: 4133 RVA: 0x0000333F File Offset: 0x0000153F
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed3()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=512");
		}

		// Token: 0x06001026 RID: 4134 RVA: 0x00003355 File Offset: 0x00001555
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000064 RID: 100
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=1024")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed4
	{
		// Token: 0x06001027 RID: 4135 RVA: 0x00003367 File Offset: 0x00001567
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed4()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=1024");
		}

		// Token: 0x06001028 RID: 4136 RVA: 0x0000337D File Offset: 0x0000157D
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000065 RID: 101
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=3068")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed5
	{
		// Token: 0x06001029 RID: 4137 RVA: 0x0000338F File Offset: 0x0000158F
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed5()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=3068");
		}

		// Token: 0x0600102A RID: 4138 RVA: 0x000033A5 File Offset: 0x000015A5
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000066 RID: 102
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=3580")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed6
	{
		// Token: 0x0600102B RID: 4139 RVA: 0x000033B7 File Offset: 0x000015B7
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed6()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=3580");
		}

		// Token: 0x0600102C RID: 4140 RVA: 0x000033CD File Offset: 0x000015CD
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr, ref this));
		}
	}
}

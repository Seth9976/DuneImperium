﻿using System;

namespace Unity.Burst
{
	// Token: 0x02000007 RID: 7
	public enum FloatPrecision
	{
		// Token: 0x04000011 RID: 17
		Standard,
		// Token: 0x04000012 RID: 18
		High,
		// Token: 0x04000013 RID: 19
		Medium,
		// Token: 0x04000014 RID: 20
		Low
	}
}

﻿using System;

namespace Unity.Burst
{
	// Token: 0x02000005 RID: 5
	public enum OptimizeFor
	{
		// Token: 0x04000006 RID: 6
		Default,
		// Token: 0x04000007 RID: 7
		Performance,
		// Token: 0x04000008 RID: 8
		Size,
		// Token: 0x04000009 RID: 9
		FastCompilation,
		// Token: 0x0400000A RID: 10
		Balanced
	}
}

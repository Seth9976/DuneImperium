﻿using System;

namespace Unity.Burst
{
	// Token: 0x0200000E RID: 14
	public enum CompilationPriority
	{
		// Token: 0x04000116 RID: 278
		EagerCompilationSynchronous,
		// Token: 0x04000117 RID: 279
		Asynchronous,
		// Token: 0x04000118 RID: 280
		ILPP,
		// Token: 0x04000119 RID: 281
		EagerCompilationAsynchronous
	}
}

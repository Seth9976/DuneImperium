﻿using System;

namespace Unity.Burst
{
	// Token: 0x0200000A RID: 10
	public enum GlobalSafetyChecksSettingKind
	{
		// Token: 0x0400005C RID: 92
		Off,
		// Token: 0x0400005D RID: 93
		On,
		// Token: 0x0400005E RID: 94
		ForceOn
	}
}

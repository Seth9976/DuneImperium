﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000024 RID: 36
	public enum JsonContainerType
	{
		// Token: 0x040000EE RID: 238
		None,
		// Token: 0x040000EF RID: 239
		Object,
		// Token: 0x040000F0 RID: 240
		Array,
		// Token: 0x040000F1 RID: 241
		Constructor
	}
}

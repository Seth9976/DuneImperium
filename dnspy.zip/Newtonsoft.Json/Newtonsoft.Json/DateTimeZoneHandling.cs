﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200000E RID: 14
	public enum DateTimeZoneHandling
	{
		// Token: 0x0400001C RID: 28
		Local,
		// Token: 0x0400001D RID: 29
		Utc,
		// Token: 0x0400001E RID: 30
		Unspecified,
		// Token: 0x0400001F RID: 31
		RoundtripKind
	}
}

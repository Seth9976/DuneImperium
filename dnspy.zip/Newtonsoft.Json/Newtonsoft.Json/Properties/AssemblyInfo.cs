﻿using System;
using System.Reflection;
using System.Runtime.Versioning;

[assembly: AssemblyAlgorithmId(0)]
[assembly: AssemblyVersion("13.0.0.0")]

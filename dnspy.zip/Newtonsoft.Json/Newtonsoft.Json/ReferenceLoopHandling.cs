﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200003A RID: 58
	public enum ReferenceLoopHandling
	{
		// Token: 0x04000545 RID: 1349
		Error,
		// Token: 0x04000546 RID: 1350
		Ignore,
		// Token: 0x04000547 RID: 1351
		Serialize
	}
}

﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000010 RID: 16
	[Flags]
	public enum DefaultValueHandling
	{
		// Token: 0x0400002B RID: 43
		Include = 0,
		// Token: 0x0400002C RID: 44
		Ignore = 1,
		// Token: 0x0400002D RID: 45
		Populate = 2,
		// Token: 0x0400002E RID: 46
		IgnoreAndPopulate = 3
	}
}

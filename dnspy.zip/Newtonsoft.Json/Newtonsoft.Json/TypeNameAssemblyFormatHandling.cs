﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200003D RID: 61
	public enum TypeNameAssemblyFormatHandling
	{
		// Token: 0x04000552 RID: 1362
		Simple,
		// Token: 0x04000553 RID: 1363
		Full
	}
}

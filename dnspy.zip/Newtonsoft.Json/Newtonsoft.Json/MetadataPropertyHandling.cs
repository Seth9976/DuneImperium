﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000035 RID: 53
	public enum MetadataPropertyHandling
	{
		// Token: 0x04000532 RID: 1330
		Default,
		// Token: 0x04000533 RID: 1331
		ReadAhead,
		// Token: 0x04000534 RID: 1332
		Ignore
	}
}

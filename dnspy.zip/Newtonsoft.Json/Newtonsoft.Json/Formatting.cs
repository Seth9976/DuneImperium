﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000013 RID: 19
	public enum Formatting
	{
		// Token: 0x04000037 RID: 55
		None,
		// Token: 0x04000038 RID: 56
		Indented
	}
}

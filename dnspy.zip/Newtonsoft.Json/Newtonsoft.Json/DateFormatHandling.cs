﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200000C RID: 12
	public enum DateFormatHandling
	{
		// Token: 0x04000015 RID: 21
		IsoDateFormat,
		// Token: 0x04000016 RID: 22
		MicrosoftDateFormat
	}
}

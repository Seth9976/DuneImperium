﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200003C RID: 60
	public enum StringEscapeHandling
	{
		// Token: 0x0400054E RID: 1358
		Default,
		// Token: 0x0400054F RID: 1359
		EscapeNonAscii,
		// Token: 0x04000550 RID: 1360
		EscapeHtml
	}
}

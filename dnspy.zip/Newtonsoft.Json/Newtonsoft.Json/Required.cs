﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200003B RID: 59
	public enum Required
	{
		// Token: 0x04000549 RID: 1353
		Default,
		// Token: 0x0400054A RID: 1354
		AllowNull,
		// Token: 0x0400054B RID: 1355
		Always,
		// Token: 0x0400054C RID: 1356
		DisallowNull
	}
}

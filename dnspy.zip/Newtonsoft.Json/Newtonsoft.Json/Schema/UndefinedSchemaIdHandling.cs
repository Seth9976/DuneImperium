﻿using System;

namespace Newtonsoft.Json.Schema
{
	// Token: 0x020000AF RID: 175
	public enum UndefinedSchemaIdHandling
	{
		// Token: 0x04000C9B RID: 3227
		None,
		// Token: 0x04000C9C RID: 3228
		UseTypeName,
		// Token: 0x04000C9D RID: 3229
		UseAssemblyQualifiedName
	}
}

﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200000D RID: 13
	public enum DateParseHandling
	{
		// Token: 0x04000018 RID: 24
		None,
		// Token: 0x04000019 RID: 25
		DateTime,
		// Token: 0x0400001A RID: 26
		DateTimeOffset
	}
}

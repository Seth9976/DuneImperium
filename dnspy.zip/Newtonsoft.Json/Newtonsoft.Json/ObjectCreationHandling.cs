﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000038 RID: 56
	public enum ObjectCreationHandling
	{
		// Token: 0x0400053C RID: 1340
		Auto,
		// Token: 0x0400053D RID: 1341
		Reuse,
		// Token: 0x0400053E RID: 1342
		Replace
	}
}

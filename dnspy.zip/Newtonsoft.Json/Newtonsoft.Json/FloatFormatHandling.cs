﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000011 RID: 17
	public enum FloatFormatHandling
	{
		// Token: 0x04000030 RID: 48
		String,
		// Token: 0x04000031 RID: 49
		Symbol,
		// Token: 0x04000032 RID: 50
		DefaultValue
	}
}

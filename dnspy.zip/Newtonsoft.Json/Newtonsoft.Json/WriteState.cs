﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200003F RID: 63
	public enum WriteState
	{
		// Token: 0x0400055B RID: 1371
		Error,
		// Token: 0x0400055C RID: 1372
		Closed,
		// Token: 0x0400055D RID: 1373
		Object,
		// Token: 0x0400055E RID: 1374
		Array,
		// Token: 0x0400055F RID: 1375
		Constructor,
		// Token: 0x04000560 RID: 1376
		Property,
		// Token: 0x04000561 RID: 1377
		Start
	}
}

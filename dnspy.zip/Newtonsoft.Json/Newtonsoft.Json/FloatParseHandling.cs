﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000012 RID: 18
	public enum FloatParseHandling
	{
		// Token: 0x04000034 RID: 52
		Double,
		// Token: 0x04000035 RID: 53
		Decimal
	}
}

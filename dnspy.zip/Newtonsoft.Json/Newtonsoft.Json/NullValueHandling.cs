﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000037 RID: 55
	public enum NullValueHandling
	{
		// Token: 0x04000539 RID: 1337
		Include,
		// Token: 0x0400053A RID: 1338
		Ignore
	}
}

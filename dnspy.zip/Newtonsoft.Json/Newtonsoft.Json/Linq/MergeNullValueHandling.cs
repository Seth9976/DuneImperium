﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020000CB RID: 203
	[Flags]
	public enum MergeNullValueHandling
	{
		// Token: 0x04000F72 RID: 3954
		Ignore = 0,
		// Token: 0x04000F73 RID: 3955
		Merge = 1
	}
}

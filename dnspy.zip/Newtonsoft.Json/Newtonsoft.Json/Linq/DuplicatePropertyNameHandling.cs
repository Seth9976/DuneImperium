﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020000B3 RID: 179
	public enum DuplicatePropertyNameHandling
	{
		// Token: 0x04000CAB RID: 3243
		Replace,
		// Token: 0x04000CAC RID: 3244
		Ignore,
		// Token: 0x04000CAD RID: 3245
		Error
	}
}

﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020000C9 RID: 201
	public enum LineInfoHandling
	{
		// Token: 0x04000F6A RID: 3946
		Ignore,
		// Token: 0x04000F6B RID: 3947
		Load
	}
}

﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020000B2 RID: 178
	public enum CommentHandling
	{
		// Token: 0x04000CA8 RID: 3240
		Ignore,
		// Token: 0x04000CA9 RID: 3241
		Load
	}
}

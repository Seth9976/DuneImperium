﻿using System;

namespace Newtonsoft.Json.Linq
{
	// Token: 0x020000CA RID: 202
	public enum MergeArrayHandling
	{
		// Token: 0x04000F6D RID: 3949
		Concat,
		// Token: 0x04000F6E RID: 3950
		Union,
		// Token: 0x04000F6F RID: 3951
		Replace,
		// Token: 0x04000F70 RID: 3952
		Merge
	}
}

﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000036 RID: 54
	public enum MissingMemberHandling
	{
		// Token: 0x04000536 RID: 1334
		Ignore,
		// Token: 0x04000537 RID: 1335
		Error
	}
}

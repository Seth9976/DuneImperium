﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200000B RID: 11
	public enum ConstructorHandling
	{
		// Token: 0x04000012 RID: 18
		Default,
		// Token: 0x04000013 RID: 19
		AllowNonPublicDefaultConstructor
	}
}

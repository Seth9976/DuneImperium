﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x0200004C RID: 76
	public enum ParserTimeZone
	{
		// Token: 0x0400062C RID: 1580
		Unspecified,
		// Token: 0x0400062D RID: 1581
		Utc,
		// Token: 0x0400062E RID: 1582
		LocalWestOfUtc,
		// Token: 0x0400062F RID: 1583
		LocalEastOfUtc
	}
}

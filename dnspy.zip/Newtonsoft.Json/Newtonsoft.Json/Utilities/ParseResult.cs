﻿using System;

namespace Newtonsoft.Json.Utilities
{
	// Token: 0x0200004A RID: 74
	public enum ParseResult
	{
		// Token: 0x04000610 RID: 1552
		None,
		// Token: 0x04000611 RID: 1553
		Success,
		// Token: 0x04000612 RID: 1554
		Overflow,
		// Token: 0x04000613 RID: 1555
		Invalid
	}
}

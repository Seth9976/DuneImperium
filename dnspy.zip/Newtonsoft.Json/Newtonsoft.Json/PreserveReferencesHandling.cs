﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000039 RID: 57
	[Flags]
	public enum PreserveReferencesHandling
	{
		// Token: 0x04000540 RID: 1344
		None = 0,
		// Token: 0x04000541 RID: 1345
		Objects = 1,
		// Token: 0x04000542 RID: 1346
		Arrays = 2,
		// Token: 0x04000543 RID: 1347
		All = 3
	}
}

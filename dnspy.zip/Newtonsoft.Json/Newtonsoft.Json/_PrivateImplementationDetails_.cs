﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000111 RID: 273
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x06001647 RID: 5703 RVA: 0x00077F04 File Offset: 0x00076104
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Newtonsoft.Json.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__772907508FD7AA0ED404C8FC80B6B772E26D67FA3C3662C22D62B871067C28DA = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "772907508FD7AA0ED404C8FC80B6B772E26D67FA3C3662C22D62B871067C28DA");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A");
		global::_PrivateImplementationDetails_.NativeMethodInfoPtr_ComputeStringHash_Internal_Static_UInt32_String_0 = IL2CPP.GetIl2CppMethodByToken(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, 100667477);
	}

	// Token: 0x06001648 RID: 5704 RVA: 0x000780F8 File Offset: 0x000762F8
	[CallerCount(34)]
	[CachedScanResults(RefRangeStart = 282344, RefRangeEnd = 282378, XrefRangeStart = 282344, XrefRangeEnd = 282378, MetadataInitTokenRva = 0L, MetadataInitFlagRva = 0L)]
	public unsafe static uint ComputeStringHash(string s)
	{
		checked
		{
			IntPtr* ptr = stackalloc IntPtr[unchecked((UIntPtr)1) * (UIntPtr)sizeof(IntPtr)];
			*ptr = IL2CPP.ManagedStringToIl2Cpp(s);
			IntPtr intPtr2;
			IntPtr intPtr = IL2CPP.il2cpp_runtime_invoke(global::_PrivateImplementationDetails_.NativeMethodInfoPtr_ComputeStringHash_Internal_Static_UInt32_String_0, 0, (void**)ptr, ref intPtr2);
			Il2CppException.RaiseExceptionIfNecessary(intPtr2);
			return *IL2CPP.il2cpp_object_unbox(intPtr);
		}
	}

	// Token: 0x06001649 RID: 5705 RVA: 0x00008ADF File Offset: 0x00006CDF
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x170005D0 RID: 1488
	// (get) Token: 0x0600164A RID: 5706 RVA: 0x0007813C File Offset: 0x0007633C
	// (set) Token: 0x0600164B RID: 5707 RVA: 0x00008AE8 File Offset: 0x00006CE8
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8 _0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139, (void*)(&value));
		}
	}

	// Token: 0x170005D1 RID: 1489
	// (get) Token: 0x0600164C RID: 5708 RVA: 0x00078158 File Offset: 0x00076358
	// (set) Token: 0x0600164D RID: 5709 RVA: 0x00008AF6 File Offset: 0x00006CF6
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994, (void*)(&value));
		}
	}

	// Token: 0x170005D2 RID: 1490
	// (get) Token: 0x0600164E RID: 5710 RVA: 0x00078174 File Offset: 0x00076374
	// (set) Token: 0x0600164F RID: 5711 RVA: 0x00008B04 File Offset: 0x00006D04
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 _223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570, (void*)(&value));
		}
	}

	// Token: 0x170005D3 RID: 1491
	// (get) Token: 0x06001650 RID: 5712 RVA: 0x00078190 File Offset: 0x00076390
	// (set) Token: 0x06001651 RID: 5713 RVA: 0x00008B12 File Offset: 0x00006D12
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 _33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE, (void*)(&value));
		}
	}

	// Token: 0x170005D4 RID: 1492
	// (get) Token: 0x06001652 RID: 5714 RVA: 0x000781AC File Offset: 0x000763AC
	// (set) Token: 0x06001653 RID: 5715 RVA: 0x00008B20 File Offset: 0x00006D20
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 _38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63, (void*)(&value));
		}
	}

	// Token: 0x170005D5 RID: 1493
	// (get) Token: 0x06001654 RID: 5716 RVA: 0x000781C8 File Offset: 0x000763C8
	// (set) Token: 0x06001655 RID: 5717 RVA: 0x00008B2E File Offset: 0x00006D2E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 _499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6, (void*)(&value));
		}
	}

	// Token: 0x170005D6 RID: 1494
	// (get) Token: 0x06001656 RID: 5718 RVA: 0x000781E4 File Offset: 0x000763E4
	// (set) Token: 0x06001657 RID: 5719 RVA: 0x00008B3C File Offset: 0x00006D3C
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 _4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF, (void*)(&value));
		}
	}

	// Token: 0x170005D7 RID: 1495
	// (get) Token: 0x06001658 RID: 5720 RVA: 0x00078200 File Offset: 0x00076400
	// (set) Token: 0x06001659 RID: 5721 RVA: 0x00008B4A File Offset: 0x00006D4A
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 _5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA, (void*)(&value));
		}
	}

	// Token: 0x170005D8 RID: 1496
	// (get) Token: 0x0600165A RID: 5722 RVA: 0x0007821C File Offset: 0x0007641C
	// (set) Token: 0x0600165B RID: 5723 RVA: 0x00008B58 File Offset: 0x00006D58
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 _5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2, (void*)(&value));
		}
	}

	// Token: 0x170005D9 RID: 1497
	// (get) Token: 0x0600165C RID: 5724 RVA: 0x00078238 File Offset: 0x00076438
	// (set) Token: 0x0600165D RID: 5725 RVA: 0x00008B66 File Offset: 0x00006D66
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 _5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9, (void*)(&value));
		}
	}

	// Token: 0x170005DA RID: 1498
	// (get) Token: 0x0600165E RID: 5726 RVA: 0x00078254 File Offset: 0x00076454
	// (set) Token: 0x0600165F RID: 5727 RVA: 0x00008B74 File Offset: 0x00006D74
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 _605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04, (void*)(&value));
		}
	}

	// Token: 0x170005DB RID: 1499
	// (get) Token: 0x06001660 RID: 5728 RVA: 0x00078270 File Offset: 0x00076470
	// (set) Token: 0x06001661 RID: 5729 RVA: 0x00008B82 File Offset: 0x00006D82
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6 _7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62, (void*)(&value));
		}
	}

	// Token: 0x170005DC RID: 1500
	// (get) Token: 0x06001662 RID: 5730 RVA: 0x0007828C File Offset: 0x0007648C
	// (set) Token: 0x06001663 RID: 5731 RVA: 0x00008B90 File Offset: 0x00006D90
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 _7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1, (void*)(&value));
		}
	}

	// Token: 0x170005DD RID: 1501
	// (get) Token: 0x06001664 RID: 5732 RVA: 0x000782A8 File Offset: 0x000764A8
	// (set) Token: 0x06001665 RID: 5733 RVA: 0x00008B9E File Offset: 0x00006D9E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _772907508FD7AA0ED404C8FC80B6B772E26D67FA3C3662C22D62B871067C28DA
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__772907508FD7AA0ED404C8FC80B6B772E26D67FA3C3662C22D62B871067C28DA, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__772907508FD7AA0ED404C8FC80B6B772E26D67FA3C3662C22D62B871067C28DA, (void*)(&value));
		}
	}

	// Token: 0x170005DE RID: 1502
	// (get) Token: 0x06001666 RID: 5734 RVA: 0x000782C4 File Offset: 0x000764C4
	// (set) Token: 0x06001667 RID: 5735 RVA: 0x00008BAC File Offset: 0x00006DAC
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 _990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5, (void*)(&value));
		}
	}

	// Token: 0x170005DF RID: 1503
	// (get) Token: 0x06001668 RID: 5736 RVA: 0x000782E0 File Offset: 0x000764E0
	// (set) Token: 0x06001669 RID: 5737 RVA: 0x00008BBA File Offset: 0x00006DBA
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89, (void*)(&value));
		}
	}

	// Token: 0x170005E0 RID: 1504
	// (get) Token: 0x0600166A RID: 5738 RVA: 0x000782FC File Offset: 0x000764FC
	// (set) Token: 0x0600166B RID: 5739 RVA: 0x00008BC8 File Offset: 0x00006DC8
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122, (void*)(&value));
		}
	}

	// Token: 0x170005E1 RID: 1505
	// (get) Token: 0x0600166C RID: 5740 RVA: 0x00078318 File Offset: 0x00076518
	// (set) Token: 0x0600166D RID: 5741 RVA: 0x00008BD6 File Offset: 0x00006DD6
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326, (void*)(&value));
		}
	}

	// Token: 0x170005E2 RID: 1506
	// (get) Token: 0x0600166E RID: 5742 RVA: 0x00078334 File Offset: 0x00076534
	// (set) Token: 0x0600166F RID: 5743 RVA: 0x00008BE4 File Offset: 0x00006DE4
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A, (void*)(&value));
		}
	}

	// Token: 0x170005E3 RID: 1507
	// (get) Token: 0x06001670 RID: 5744 RVA: 0x00078350 File Offset: 0x00076550
	// (set) Token: 0x06001671 RID: 5745 RVA: 0x00008BF2 File Offset: 0x00006DF2
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7, (void*)(&value));
		}
	}

	// Token: 0x170005E4 RID: 1508
	// (get) Token: 0x06001672 RID: 5746 RVA: 0x0007836C File Offset: 0x0007656C
	// (set) Token: 0x06001673 RID: 5747 RVA: 0x00008C00 File Offset: 0x00006E00
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315, (void*)(&value));
		}
	}

	// Token: 0x170005E5 RID: 1509
	// (get) Token: 0x06001674 RID: 5748 RVA: 0x00078388 File Offset: 0x00076588
	// (set) Token: 0x06001675 RID: 5749 RVA: 0x00008C0E File Offset: 0x00006E0E
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A, (void*)(&value));
		}
	}

	// Token: 0x04001204 RID: 4612
	private static readonly IntPtr NativeFieldInfoPtr__0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139;

	// Token: 0x04001205 RID: 4613
	private static readonly IntPtr NativeFieldInfoPtr__19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994;

	// Token: 0x04001206 RID: 4614
	private static readonly IntPtr NativeFieldInfoPtr__223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570;

	// Token: 0x04001207 RID: 4615
	private static readonly IntPtr NativeFieldInfoPtr__33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE;

	// Token: 0x04001208 RID: 4616
	private static readonly IntPtr NativeFieldInfoPtr__38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63;

	// Token: 0x04001209 RID: 4617
	private static readonly IntPtr NativeFieldInfoPtr__499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6;

	// Token: 0x0400120A RID: 4618
	private static readonly IntPtr NativeFieldInfoPtr__4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF;

	// Token: 0x0400120B RID: 4619
	private static readonly IntPtr NativeFieldInfoPtr__5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA;

	// Token: 0x0400120C RID: 4620
	private static readonly IntPtr NativeFieldInfoPtr__5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2;

	// Token: 0x0400120D RID: 4621
	private static readonly IntPtr NativeFieldInfoPtr__5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9;

	// Token: 0x0400120E RID: 4622
	private static readonly IntPtr NativeFieldInfoPtr__605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04;

	// Token: 0x0400120F RID: 4623
	private static readonly IntPtr NativeFieldInfoPtr__7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62;

	// Token: 0x04001210 RID: 4624
	private static readonly IntPtr NativeFieldInfoPtr__7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1;

	// Token: 0x04001211 RID: 4625
	private static readonly IntPtr NativeFieldInfoPtr__772907508FD7AA0ED404C8FC80B6B772E26D67FA3C3662C22D62B871067C28DA;

	// Token: 0x04001212 RID: 4626
	private static readonly IntPtr NativeFieldInfoPtr__990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5;

	// Token: 0x04001213 RID: 4627
	private static readonly IntPtr NativeFieldInfoPtr_A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89;

	// Token: 0x04001214 RID: 4628
	private static readonly IntPtr NativeFieldInfoPtr_B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122;

	// Token: 0x04001215 RID: 4629
	private static readonly IntPtr NativeFieldInfoPtr_CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326;

	// Token: 0x04001216 RID: 4630
	private static readonly IntPtr NativeFieldInfoPtr_D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A;

	// Token: 0x04001217 RID: 4631
	private static readonly IntPtr NativeFieldInfoPtr_F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7;

	// Token: 0x04001218 RID: 4632
	private static readonly IntPtr NativeFieldInfoPtr_FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315;

	// Token: 0x04001219 RID: 4633
	private static readonly IntPtr NativeFieldInfoPtr_FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A;

	// Token: 0x0400121A RID: 4634
	private static readonly IntPtr NativeMethodInfoPtr_ComputeStringHash_Internal_Static_UInt32_String_0;

	// Token: 0x02000229 RID: 553
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=6")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060022C3 RID: 8899 RVA: 0x00011BA3 File Offset: 0x0000FDA3
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=6");
		}

		// Token: 0x060022C4 RID: 8900 RVA: 0x00011BB9 File Offset: 0x0000FDB9
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200022A RID: 554
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=10")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060022C5 RID: 8901 RVA: 0x00011BCB File Offset: 0x0000FDCB
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=10");
		}

		// Token: 0x060022C6 RID: 8902 RVA: 0x00011BE1 File Offset: 0x0000FDE1
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200022B RID: 555
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=16")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed2
	{
		// Token: 0x060022C7 RID: 8903 RVA: 0x00011BF3 File Offset: 0x0000FDF3
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed2()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=16");
		}

		// Token: 0x060022C8 RID: 8904 RVA: 0x00011C09 File Offset: 0x0000FE09
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed2>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200022C RID: 556
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=20")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed3
	{
		// Token: 0x060022C9 RID: 8905 RVA: 0x00011C1B File Offset: 0x0000FE1B
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed3()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=20");
		}

		// Token: 0x060022CA RID: 8906 RVA: 0x00011C31 File Offset: 0x0000FE31
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed3>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200022D RID: 557
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=24")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed4
	{
		// Token: 0x060022CB RID: 8907 RVA: 0x00011C43 File Offset: 0x0000FE43
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed4()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=24");
		}

		// Token: 0x060022CC RID: 8908 RVA: 0x00011C59 File Offset: 0x0000FE59
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed4>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200022E RID: 558
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=28")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed5
	{
		// Token: 0x060022CD RID: 8909 RVA: 0x00011C6B File Offset: 0x0000FE6B
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed5()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=28");
		}

		// Token: 0x060022CE RID: 8910 RVA: 0x00011C81 File Offset: 0x0000FE81
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed5>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200022F RID: 559
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=36")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed6
	{
		// Token: 0x060022CF RID: 8911 RVA: 0x00011C93 File Offset: 0x0000FE93
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed6()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=36");
		}

		// Token: 0x060022D0 RID: 8912 RVA: 0x00011CA9 File Offset: 0x0000FEA9
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed6>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000230 RID: 560
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=40")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed7
	{
		// Token: 0x060022D1 RID: 8913 RVA: 0x00011CBB File Offset: 0x0000FEBB
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed7()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=40");
		}

		// Token: 0x060022D2 RID: 8914 RVA: 0x00011CD1 File Offset: 0x0000FED1
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed7>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000231 RID: 561
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=44")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed8
	{
		// Token: 0x060022D3 RID: 8915 RVA: 0x00011CE3 File Offset: 0x0000FEE3
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed8()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=44");
		}

		// Token: 0x060022D4 RID: 8916 RVA: 0x00011CF9 File Offset: 0x0000FEF9
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed8>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000232 RID: 562
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=52")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed9
	{
		// Token: 0x060022D5 RID: 8917 RVA: 0x00011D0B File Offset: 0x0000FF0B
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed9()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=52");
		}

		// Token: 0x060022D6 RID: 8918 RVA: 0x00011D21 File Offset: 0x0000FF21
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed9>.NativeClassPtr, ref this));
		}
	}
}

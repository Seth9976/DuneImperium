﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x02000034 RID: 52
	public enum MemberSerialization
	{
		// Token: 0x0400052E RID: 1326
		OptOut,
		// Token: 0x0400052F RID: 1327
		OptIn,
		// Token: 0x04000530 RID: 1328
		Fields
	}
}

﻿using System;

namespace Newtonsoft.Json
{
	// Token: 0x0200003E RID: 62
	[Flags]
	public enum TypeNameHandling
	{
		// Token: 0x04000555 RID: 1365
		None = 0,
		// Token: 0x04000556 RID: 1366
		Objects = 1,
		// Token: 0x04000557 RID: 1367
		Arrays = 2,
		// Token: 0x04000558 RID: 1368
		All = 3,
		// Token: 0x04000559 RID: 1369
		Auto = 4
	}
}

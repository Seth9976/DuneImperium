﻿using System;
using Il2CppInterop.Common.Attributes;

namespace Il2CppMono.Options
{
	// Token: 0x0200000B RID: 11
	[OriginalName("platform.dll", "Mono.Options", "OptionValueType")]
	public enum OptionValueType
	{
		// Token: 0x04000065 RID: 101
		None,
		// Token: 0x04000066 RID: 102
		Optional,
		// Token: 0x04000067 RID: 103
		Required
	}
}

﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000058 RID: 88
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x06000378 RID: 888 RVA: 0x00010D98 File Offset: 0x0000EF98
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("platform.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CC35C7F14FF60AD69DCA0DEC576E84973080B137583EC268EA413A104224C2EC = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "CC35C7F14FF60AD69DCA0DEC576E84973080B137583EC268EA413A104224C2EC");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_ED714CDA94D6CFA8FE1F9878ED8742A51D6B116AB1EA1345BA05619F8CA537C5 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "ED714CDA94D6CFA8FE1F9878ED8742A51D6B116AB1EA1345BA05619F8CA537C5");
	}

	// Token: 0x06000379 RID: 889 RVA: 0x000039BB File Offset: 0x00001BBB
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x170000DE RID: 222
	// (get) Token: 0x0600037A RID: 890 RVA: 0x00010DE8 File Offset: 0x0000EFE8
	// (set) Token: 0x0600037B RID: 891 RVA: 0x000039C4 File Offset: 0x00001BC4
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 CC35C7F14FF60AD69DCA0DEC576E84973080B137583EC268EA413A104224C2EC
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CC35C7F14FF60AD69DCA0DEC576E84973080B137583EC268EA413A104224C2EC, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_CC35C7F14FF60AD69DCA0DEC576E84973080B137583EC268EA413A104224C2EC, (void*)(&value));
		}
	}

	// Token: 0x170000DF RID: 223
	// (get) Token: 0x0600037C RID: 892 RVA: 0x00010E04 File Offset: 0x0000F004
	// (set) Token: 0x0600037D RID: 893 RVA: 0x000039D2 File Offset: 0x00001BD2
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 ED714CDA94D6CFA8FE1F9878ED8742A51D6B116AB1EA1345BA05619F8CA537C5
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_ED714CDA94D6CFA8FE1F9878ED8742A51D6B116AB1EA1345BA05619F8CA537C5, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_ED714CDA94D6CFA8FE1F9878ED8742A51D6B116AB1EA1345BA05619F8CA537C5, (void*)(&value));
		}
	}

	// Token: 0x0400023E RID: 574
	private static readonly IntPtr NativeFieldInfoPtr_CC35C7F14FF60AD69DCA0DEC576E84973080B137583EC268EA413A104224C2EC;

	// Token: 0x0400023F RID: 575
	private static readonly IntPtr NativeFieldInfoPtr_ED714CDA94D6CFA8FE1F9878ED8742A51D6B116AB1EA1345BA05619F8CA537C5;

	// Token: 0x02000086 RID: 134
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=4311")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060004FA RID: 1274 RVA: 0x0000469F File Offset: 0x0000289F
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=4311");
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x000046B5 File Offset: 0x000028B5
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000087 RID: 135
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=5264")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060004FC RID: 1276 RVA: 0x000046C7 File Offset: 0x000028C7
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=5264");
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x000046DD File Offset: 0x000028DD
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

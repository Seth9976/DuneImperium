﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x0200000C RID: 12
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x0600003E RID: 62 RVA: 0x00003094 File Offset: 0x00001294
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("analytics.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__121F3070AD7BD0C6FCF1625DC5F007DA421E234059E8B4AC53EE90ADE5B8675F = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "121F3070AD7BD0C6FCF1625DC5F007DA421E234059E8B4AC53EE90ADE5B8675F");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__204B1219D3212ED3E9FE23C75AA712C3D5940688ADC6659D5EBE4366E5B1F874 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "204B1219D3212ED3E9FE23C75AA712C3D5940688ADC6659D5EBE4366E5B1F874");
	}

	// Token: 0x0600003F RID: 63 RVA: 0x0000216D File Offset: 0x0000036D
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000040 RID: 64 RVA: 0x000030E4 File Offset: 0x000012E4
	// (set) Token: 0x06000041 RID: 65 RVA: 0x00002176 File Offset: 0x00000376
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _121F3070AD7BD0C6FCF1625DC5F007DA421E234059E8B4AC53EE90ADE5B8675F
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__121F3070AD7BD0C6FCF1625DC5F007DA421E234059E8B4AC53EE90ADE5B8675F, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__121F3070AD7BD0C6FCF1625DC5F007DA421E234059E8B4AC53EE90ADE5B8675F, (void*)(&value));
		}
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x06000042 RID: 66 RVA: 0x00003100 File Offset: 0x00001300
	// (set) Token: 0x06000043 RID: 67 RVA: 0x00002184 File Offset: 0x00000384
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _204B1219D3212ED3E9FE23C75AA712C3D5940688ADC6659D5EBE4366E5B1F874
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__204B1219D3212ED3E9FE23C75AA712C3D5940688ADC6659D5EBE4366E5B1F874, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__204B1219D3212ED3E9FE23C75AA712C3D5940688ADC6659D5EBE4366E5B1F874, (void*)(&value));
		}
	}

	// Token: 0x04000025 RID: 37
	private static readonly IntPtr NativeFieldInfoPtr__121F3070AD7BD0C6FCF1625DC5F007DA421E234059E8B4AC53EE90ADE5B8675F;

	// Token: 0x04000026 RID: 38
	private static readonly IntPtr NativeFieldInfoPtr__204B1219D3212ED3E9FE23C75AA712C3D5940688ADC6659D5EBE4366E5B1F874;

	// Token: 0x0200000F RID: 15
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=194")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x06000059 RID: 89 RVA: 0x00002269 File Offset: 0x00000469
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=194");
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000227F File Offset: 0x0000047F
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000010 RID: 16
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=338")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x0600005B RID: 91 RVA: 0x00002291 File Offset: 0x00000491
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=338");
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000022A7 File Offset: 0x000004A7
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

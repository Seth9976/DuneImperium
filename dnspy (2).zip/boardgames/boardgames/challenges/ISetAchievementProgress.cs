﻿using System;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

namespace boardgames.challenges
{
	// Token: 0x02000155 RID: 341
	public class ISetAchievementProgress : Il2CppObjectBase
	{
		// Token: 0x0600115F RID: 4447 RVA: 0x0000A203 File Offset: 0x00008403
		// Note: this type is marked as 'beforefieldinit'.
		static ISetAchievementProgress()
		{
			Il2CppClassPointerStore<ISetAchievementProgress>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames.dll", "boardgames.challenges", "ISetAchievementProgress");
		}

		// Token: 0x06001160 RID: 4448 RVA: 0x0000A21E File Offset: 0x0000841E
		public ISetAchievementProgress(IntPtr pointer)
			: base(pointer)
		{
		}
	}
}

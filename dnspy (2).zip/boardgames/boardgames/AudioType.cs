﻿using System;

// Token: 0x02000008 RID: 8
public enum AudioType
{
	// Token: 0x0400000C RID: 12
	Master,
	// Token: 0x0400000D RID: 13
	Music,
	// Token: 0x0400000E RID: 14
	SFX,
	// Token: 0x0400000F RID: 15
	Ambience
}

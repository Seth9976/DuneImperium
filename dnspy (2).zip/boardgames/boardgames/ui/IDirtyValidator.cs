﻿using System;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

namespace boardgames.ui
{
	// Token: 0x02000121 RID: 289
	public class IDirtyValidator : Il2CppObjectBase
	{
		// Token: 0x06000EE8 RID: 3816 RVA: 0x00008FB5 File Offset: 0x000071B5
		// Note: this type is marked as 'beforefieldinit'.
		static IDirtyValidator()
		{
			Il2CppClassPointerStore<IDirtyValidator>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames.dll", "boardgames.ui", "IDirtyValidator");
		}

		// Token: 0x06000EE9 RID: 3817 RVA: 0x00008FD0 File Offset: 0x000071D0
		public IDirtyValidator(IntPtr pointer)
			: base(pointer)
		{
		}
	}
}

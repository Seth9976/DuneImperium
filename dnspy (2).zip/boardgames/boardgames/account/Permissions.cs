﻿using System;

namespace boardgames.account
{
	// Token: 0x02000183 RID: 387
	public enum Permissions
	{
		// Token: 0x04000B9A RID: 2970
		Crossplay,
		// Token: 0x04000B9B RID: 2971
		Communications,
		// Token: 0x04000B9C RID: 2972
		Multiplayer
	}
}

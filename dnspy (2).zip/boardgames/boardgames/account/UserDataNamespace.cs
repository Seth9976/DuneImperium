﻿using System;

namespace boardgames.account
{
	// Token: 0x02000188 RID: 392
	public enum UserDataNamespace
	{
		// Token: 0x04000BA5 RID: 2981
		Canis,
		// Token: 0x04000BA6 RID: 2982
		GameCore
	}
}

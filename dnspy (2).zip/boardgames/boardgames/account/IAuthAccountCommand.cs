﻿using System;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

namespace boardgames.account
{
	// Token: 0x02000182 RID: 386
	public class IAuthAccountCommand : Il2CppObjectBase
	{
		// Token: 0x0600131B RID: 4891 RVA: 0x0000AE9A File Offset: 0x0000909A
		// Note: this type is marked as 'beforefieldinit'.
		static IAuthAccountCommand()
		{
			Il2CppClassPointerStore<IAuthAccountCommand>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames.dll", "boardgames.account", "IAuthAccountCommand");
		}

		// Token: 0x0600131C RID: 4892 RVA: 0x0000AEB5 File Offset: 0x000090B5
		public IAuthAccountCommand(IntPtr pointer)
			: base(pointer)
		{
		}
	}
}

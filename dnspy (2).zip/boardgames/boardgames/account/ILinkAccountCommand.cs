﻿using System;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

namespace boardgames.account
{
	// Token: 0x02000185 RID: 389
	public class ILinkAccountCommand : Il2CppObjectBase
	{
		// Token: 0x06001324 RID: 4900 RVA: 0x0000AEE4 File Offset: 0x000090E4
		// Note: this type is marked as 'beforefieldinit'.
		static ILinkAccountCommand()
		{
			Il2CppClassPointerStore<ILinkAccountCommand>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames.dll", "boardgames.account", "ILinkAccountCommand");
		}

		// Token: 0x06001325 RID: 4901 RVA: 0x0000AEFF File Offset: 0x000090FF
		public ILinkAccountCommand(IntPtr pointer)
			: base(pointer)
		{
		}
	}
}

﻿using System;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

namespace boardgames.account
{
	// Token: 0x02000186 RID: 390
	public class IOpenUserDetails : Il2CppObjectBase
	{
		// Token: 0x06001326 RID: 4902 RVA: 0x0000AF08 File Offset: 0x00009108
		// Note: this type is marked as 'beforefieldinit'.
		static IOpenUserDetails()
		{
			Il2CppClassPointerStore<IOpenUserDetails>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames.dll", "boardgames.account", "IOpenUserDetails");
		}

		// Token: 0x06001327 RID: 4903 RVA: 0x0000AF23 File Offset: 0x00009123
		public IOpenUserDetails(IntPtr pointer)
			: base(pointer)
		{
		}
	}
}

﻿using System;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;

// Token: 0x02000007 RID: 7
public class IUnlinkAccountCommand : Il2CppObjectBase
{
	// Token: 0x06000018 RID: 24 RVA: 0x0000213E File Offset: 0x0000033E
	// Note: this type is marked as 'beforefieldinit'.
	static IUnlinkAccountCommand()
	{
		Il2CppClassPointerStore<IUnlinkAccountCommand>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames.dll", "", "IUnlinkAccountCommand");
	}

	// Token: 0x06000019 RID: 25 RVA: 0x00002159 File Offset: 0x00000359
	public IUnlinkAccountCommand(IntPtr pointer)
		: base(pointer)
	{
	}
}

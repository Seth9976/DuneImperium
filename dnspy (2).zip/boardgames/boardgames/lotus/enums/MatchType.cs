﻿using System;

namespace lotus.enums
{
	// Token: 0x020000E4 RID: 228
	public enum MatchType
	{
		// Token: 0x040006ED RID: 1773
		PBM,
		// Token: 0x040006EE RID: 1774
		Tutorial,
		// Token: 0x040006EF RID: 1775
		Solo,
		// Token: 0x040006F0 RID: 1776
		Friend,
		// Token: 0x040006F1 RID: 1777
		PassAndPlay
	}
}

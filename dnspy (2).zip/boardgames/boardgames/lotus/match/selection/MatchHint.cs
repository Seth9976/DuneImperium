﻿using System;

namespace lotus.match.selection
{
	// Token: 0x020000E6 RID: 230
	public enum MatchHint
	{
		// Token: 0x04000700 RID: 1792
		NONE,
		// Token: 0x04000701 RID: 1793
		Select,
		// Token: 0x04000702 RID: 1794
		Unselect,
		// Token: 0x04000703 RID: 1795
		Droppable
	}
}

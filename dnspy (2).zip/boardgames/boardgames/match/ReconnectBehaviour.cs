﻿using System;

namespace boardgames.match
{
	// Token: 0x0200012A RID: 298
	public enum ReconnectBehaviour
	{
		// Token: 0x04000981 RID: 2433
		None,
		// Token: 0x04000982 RID: 2434
		ReturnToMainMenu,
		// Token: 0x04000983 RID: 2435
		ReloadPlaymat
	}
}

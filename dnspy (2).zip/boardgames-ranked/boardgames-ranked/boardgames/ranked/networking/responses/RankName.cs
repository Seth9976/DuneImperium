﻿using System;

namespace boardgames.ranked.networking.responses
{
	// Token: 0x02000013 RID: 19
	public enum RankName
	{
		// Token: 0x0400003D RID: 61
		Bronze,
		// Token: 0x0400003E RID: 62
		Silver,
		// Token: 0x0400003F RID: 63
		Gold,
		// Token: 0x04000040 RID: 64
		Platinum,
		// Token: 0x04000041 RID: 65
		Master = 5
	}
}

﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x0200003C RID: 60
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060001FA RID: 506 RVA: 0x000091C0 File Offset: 0x000073C0
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames-ranked.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__1F77E8A71EF6762B5C0C29553610AEAC23AC0268A1A9017ED03397BEA1812988 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "1F77E8A71EF6762B5C0C29553610AEAC23AC0268A1A9017ED03397BEA1812988");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E0FFFD6E956C5D3B12FD2BE0F305C8C48F915617E9C3C921FC7CF7C2E4BAF3A6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "E0FFFD6E956C5D3B12FD2BE0F305C8C48F915617E9C3C921FC7CF7C2E4BAF3A6");
	}

	// Token: 0x060001FB RID: 507 RVA: 0x00003164 File Offset: 0x00001364
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x17000088 RID: 136
	// (get) Token: 0x060001FC RID: 508 RVA: 0x00009210 File Offset: 0x00007410
	// (set) Token: 0x060001FD RID: 509 RVA: 0x0000316D File Offset: 0x0000136D
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 _1F77E8A71EF6762B5C0C29553610AEAC23AC0268A1A9017ED03397BEA1812988
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__1F77E8A71EF6762B5C0C29553610AEAC23AC0268A1A9017ED03397BEA1812988, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__1F77E8A71EF6762B5C0C29553610AEAC23AC0268A1A9017ED03397BEA1812988, (void*)(&value));
		}
	}

	// Token: 0x17000089 RID: 137
	// (get) Token: 0x060001FE RID: 510 RVA: 0x0000922C File Offset: 0x0000742C
	// (set) Token: 0x060001FF RID: 511 RVA: 0x0000317B File Offset: 0x0000137B
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 E0FFFD6E956C5D3B12FD2BE0F305C8C48F915617E9C3C921FC7CF7C2E4BAF3A6
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E0FFFD6E956C5D3B12FD2BE0F305C8C48F915617E9C3C921FC7CF7C2E4BAF3A6, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E0FFFD6E956C5D3B12FD2BE0F305C8C48F915617E9C3C921FC7CF7C2E4BAF3A6, (void*)(&value));
		}
	}

	// Token: 0x04000118 RID: 280
	private static readonly IntPtr NativeFieldInfoPtr__1F77E8A71EF6762B5C0C29553610AEAC23AC0268A1A9017ED03397BEA1812988;

	// Token: 0x04000119 RID: 281
	private static readonly IntPtr NativeFieldInfoPtr_E0FFFD6E956C5D3B12FD2BE0F305C8C48F915617E9C3C921FC7CF7C2E4BAF3A6;

	// Token: 0x0200004D RID: 77
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=3046")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060002D4 RID: 724 RVA: 0x000038AB File Offset: 0x00001AAB
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=3046");
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x000038C1 File Offset: 0x00001AC1
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200004E RID: 78
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=3628")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060002D6 RID: 726 RVA: 0x000038D3 File Offset: 0x00001AD3
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=3628");
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x000038E9 File Offset: 0x00001AE9
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

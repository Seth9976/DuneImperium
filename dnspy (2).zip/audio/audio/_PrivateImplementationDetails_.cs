﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x0200001A RID: 26
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060000F3 RID: 243 RVA: 0x00005928 File Offset: 0x00003B28
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("audio.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__250CD64AAEC88A4B8EFEFA0438B22D6F0DA28BA69BF9C503F28942D9D7410157 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "250CD64AAEC88A4B8EFEFA0438B22D6F0DA28BA69BF9C503F28942D9D7410157");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E68CBFD2C68877D65B7F39EAB2168B31860626C754707971D05160EC83FFB3A6 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "E68CBFD2C68877D65B7F39EAB2168B31860626C754707971D05160EC83FFB3A6");
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x0000274D File Offset: 0x0000094D
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x060000F5 RID: 245 RVA: 0x00005978 File Offset: 0x00003B78
	// (set) Token: 0x060000F6 RID: 246 RVA: 0x00002756 File Offset: 0x00000956
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _250CD64AAEC88A4B8EFEFA0438B22D6F0DA28BA69BF9C503F28942D9D7410157
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__250CD64AAEC88A4B8EFEFA0438B22D6F0DA28BA69BF9C503F28942D9D7410157, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__250CD64AAEC88A4B8EFEFA0438B22D6F0DA28BA69BF9C503F28942D9D7410157, (void*)(&value));
		}
	}

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x060000F7 RID: 247 RVA: 0x00005994 File Offset: 0x00003B94
	// (set) Token: 0x060000F8 RID: 248 RVA: 0x00002764 File Offset: 0x00000964
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 E68CBFD2C68877D65B7F39EAB2168B31860626C754707971D05160EC83FFB3A6
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E68CBFD2C68877D65B7F39EAB2168B31860626C754707971D05160EC83FFB3A6, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_E68CBFD2C68877D65B7F39EAB2168B31860626C754707971D05160EC83FFB3A6, (void*)(&value));
		}
	}

	// Token: 0x04000090 RID: 144
	private static readonly IntPtr NativeFieldInfoPtr__250CD64AAEC88A4B8EFEFA0438B22D6F0DA28BA69BF9C503F28942D9D7410157;

	// Token: 0x04000091 RID: 145
	private static readonly IntPtr NativeFieldInfoPtr_E68CBFD2C68877D65B7F39EAB2168B31860626C754707971D05160EC83FFB3A6;

	// Token: 0x02000023 RID: 35
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=920")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x0600014F RID: 335 RVA: 0x00002A7F File Offset: 0x00000C7F
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=920");
		}

		// Token: 0x06000150 RID: 336 RVA: 0x00002A95 File Offset: 0x00000C95
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000024 RID: 36
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=1138")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x06000151 RID: 337 RVA: 0x00002AA7 File Offset: 0x00000CA7
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=1138");
		}

		// Token: 0x06000152 RID: 338 RVA: 0x00002ABD File Offset: 0x00000CBD
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x02000004 RID: 4
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x0600005D RID: 93 RVA: 0x00002E34 File Offset: 0x00001034
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Assembly-CSharp.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6E292276AA2873967276620370C3C8BB895E0D5AFCD6B2C422352B1A275DE205 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "6E292276AA2873967276620370C3C8BB895E0D5AFCD6B2C422352B1A275DE205");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_DEAE8EB9D265D0709DC9E97534424B025DC24D3CDD295CA78023FBE65344D99A = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "DEAE8EB9D265D0709DC9E97534424B025DC24D3CDD295CA78023FBE65344D99A");
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00002368 File Offset: 0x00000568
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600005F RID: 95 RVA: 0x00002E84 File Offset: 0x00001084
	// (set) Token: 0x06000060 RID: 96 RVA: 0x00002371 File Offset: 0x00000571
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _6E292276AA2873967276620370C3C8BB895E0D5AFCD6B2C422352B1A275DE205
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6E292276AA2873967276620370C3C8BB895E0D5AFCD6B2C422352B1A275DE205, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__6E292276AA2873967276620370C3C8BB895E0D5AFCD6B2C422352B1A275DE205, (void*)(&value));
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000061 RID: 97 RVA: 0x00002EA0 File Offset: 0x000010A0
	// (set) Token: 0x06000062 RID: 98 RVA: 0x0000237F File Offset: 0x0000057F
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 DEAE8EB9D265D0709DC9E97534424B025DC24D3CDD295CA78023FBE65344D99A
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_DEAE8EB9D265D0709DC9E97534424B025DC24D3CDD295CA78023FBE65344D99A, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_DEAE8EB9D265D0709DC9E97534424B025DC24D3CDD295CA78023FBE65344D99A, (void*)(&value));
		}
	}

	// Token: 0x0400002E RID: 46
	private static readonly IntPtr NativeFieldInfoPtr__6E292276AA2873967276620370C3C8BB895E0D5AFCD6B2C422352B1A275DE205;

	// Token: 0x0400002F RID: 47
	private static readonly IntPtr NativeFieldInfoPtr_DEAE8EB9D265D0709DC9E97534424B025DC24D3CDD295CA78023FBE65344D99A;

	// Token: 0x02000006 RID: 6
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=13")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x06000070 RID: 112 RVA: 0x00002437 File Offset: 0x00000637
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=13");
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000244D File Offset: 0x0000064D
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x02000007 RID: 7
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=26")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x06000072 RID: 114 RVA: 0x0000245F File Offset: 0x0000065F
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=26");
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00002475 File Offset: 0x00000675
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x0200001E RID: 30
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060000FC RID: 252 RVA: 0x000062D8 File Offset: 0x000044D8
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("boardgames-cutscenes.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F413052A9B9D78994EBCE5AE6E26249EFA20E87B2F65DF3AD6223081AE4EA686 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "F413052A9B9D78994EBCE5AE6E26249EFA20E87B2F65DF3AD6223081AE4EA686");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FE1F461F3E1DF2EF094332AAA11EB225CDD29BD2D7C1B7E51A42BFA039038CF3 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "FE1F461F3E1DF2EF094332AAA11EB225CDD29BD2D7C1B7E51A42BFA039038CF3");
	}

	// Token: 0x060000FD RID: 253 RVA: 0x0000265F File Offset: 0x0000085F
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x060000FE RID: 254 RVA: 0x00006328 File Offset: 0x00004528
	// (set) Token: 0x060000FF RID: 255 RVA: 0x00002668 File Offset: 0x00000868
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 F413052A9B9D78994EBCE5AE6E26249EFA20E87B2F65DF3AD6223081AE4EA686
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F413052A9B9D78994EBCE5AE6E26249EFA20E87B2F65DF3AD6223081AE4EA686, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_F413052A9B9D78994EBCE5AE6E26249EFA20E87B2F65DF3AD6223081AE4EA686, (void*)(&value));
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000100 RID: 256 RVA: 0x00006344 File Offset: 0x00004544
	// (set) Token: 0x06000101 RID: 257 RVA: 0x00002676 File Offset: 0x00000876
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 FE1F461F3E1DF2EF094332AAA11EB225CDD29BD2D7C1B7E51A42BFA039038CF3
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FE1F461F3E1DF2EF094332AAA11EB225CDD29BD2D7C1B7E51A42BFA039038CF3, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_FE1F461F3E1DF2EF094332AAA11EB225CDD29BD2D7C1B7E51A42BFA039038CF3, (void*)(&value));
		}
	}

	// Token: 0x04000098 RID: 152
	private static readonly IntPtr NativeFieldInfoPtr_F413052A9B9D78994EBCE5AE6E26249EFA20E87B2F65DF3AD6223081AE4EA686;

	// Token: 0x04000099 RID: 153
	private static readonly IntPtr NativeFieldInfoPtr_FE1F461F3E1DF2EF094332AAA11EB225CDD29BD2D7C1B7E51A42BFA039038CF3;

	// Token: 0x0200002E RID: 46
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=770")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x060001D2 RID: 466 RVA: 0x00002CD6 File Offset: 0x00000ED6
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=770");
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00002CEC File Offset: 0x00000EEC
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200002F RID: 47
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=2001")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x060001D4 RID: 468 RVA: 0x00002CFE File Offset: 0x00000EFE
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=2001");
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x00002D14 File Offset: 0x00000F14
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}

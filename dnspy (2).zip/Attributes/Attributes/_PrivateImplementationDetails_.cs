﻿using System;
using System.Runtime.InteropServices;
using Il2CppInterop.Common.Attributes;
using Il2CppInterop.Runtime;
using Il2CppSystem;

// Token: 0x0200002A RID: 42
[ObfuscatedName("<PrivateImplementationDetails>")]
public sealed class _PrivateImplementationDetails_ : Object
{
	// Token: 0x060002D3 RID: 723 RVA: 0x0000DC10 File Offset: 0x0000BE10
	// Note: this type is marked as 'beforefieldinit'.
	static _PrivateImplementationDetails_()
	{
		Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr = IL2CPP.GetIl2CppClass("Attributes.dll", "", "<PrivateImplementationDetails>");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr__181FB3B81DC86092D20029A5F0E8AAAA1CE1DFF64DF7A9A1DD4EF7AEC72E1F87 = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "181FB3B81DC86092D20029A5F0E8AAAA1CE1DFF64DF7A9A1DD4EF7AEC72E1F87");
		global::_PrivateImplementationDetails_.NativeFieldInfoPtr_EB978CBFD0D32B5F19462953B22BBE8B321FBC5BB401D7464EF27175BF14052C = IL2CPP.GetIl2CppField(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "EB978CBFD0D32B5F19462953B22BBE8B321FBC5BB401D7464EF27175BF14052C");
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x00003114 File Offset: 0x00001314
	public _PrivateImplementationDetails_(IntPtr pointer)
		: base(pointer)
	{
	}

	// Token: 0x1700010D RID: 269
	// (get) Token: 0x060002D5 RID: 725 RVA: 0x0000DC60 File Offset: 0x0000BE60
	// (set) Token: 0x060002D6 RID: 726 RVA: 0x0000311D File Offset: 0x0000131D
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 _181FB3B81DC86092D20029A5F0E8AAAA1CE1DFF64DF7A9A1DD4EF7AEC72E1F87
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__181FB3B81DC86092D20029A5F0E8AAAA1CE1DFF64DF7A9A1DD4EF7AEC72E1F87, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr__181FB3B81DC86092D20029A5F0E8AAAA1CE1DFF64DF7A9A1DD4EF7AEC72E1F87, (void*)(&value));
		}
	}

	// Token: 0x1700010E RID: 270
	// (get) Token: 0x060002D7 RID: 727 RVA: 0x0000DC7C File Offset: 0x0000BE7C
	// (set) Token: 0x060002D8 RID: 728 RVA: 0x0000312B File Offset: 0x0000132B
	public unsafe static global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 EB978CBFD0D32B5F19462953B22BBE8B321FBC5BB401D7464EF27175BF14052C
	{
		get
		{
			global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1 valueTypeNPrivateSealed;
			IL2CPP.il2cpp_field_static_get_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_EB978CBFD0D32B5F19462953B22BBE8B321FBC5BB401D7464EF27175BF14052C, (void*)(&valueTypeNPrivateSealed));
			return valueTypeNPrivateSealed;
		}
		set
		{
			IL2CPP.il2cpp_field_static_set_value(global::_PrivateImplementationDetails_.NativeFieldInfoPtr_EB978CBFD0D32B5F19462953B22BBE8B321FBC5BB401D7464EF27175BF14052C, (void*)(&value));
		}
	}

	// Token: 0x040001CB RID: 459
	private static readonly IntPtr NativeFieldInfoPtr__181FB3B81DC86092D20029A5F0E8AAAA1CE1DFF64DF7A9A1DD4EF7AEC72E1F87;

	// Token: 0x040001CC RID: 460
	private static readonly IntPtr NativeFieldInfoPtr_EB978CBFD0D32B5F19462953B22BBE8B321FBC5BB401D7464EF27175BF14052C;

	// Token: 0x0200005C RID: 92
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=1397")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed0
	{
		// Token: 0x0600039A RID: 922 RVA: 0x00003632 File Offset: 0x00001832
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed0()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=1397");
		}

		// Token: 0x0600039B RID: 923 RVA: 0x00003648 File Offset: 0x00001848
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed0>.NativeClassPtr, ref this));
		}
	}

	// Token: 0x0200005D RID: 93
	[ObfuscatedName("<PrivateImplementationDetails>+__StaticArrayInitTypeSize=1535")]
	[StructLayout(2)]
	public struct ValueTypeNPrivateSealed1
	{
		// Token: 0x0600039C RID: 924 RVA: 0x0000365A File Offset: 0x0000185A
		// Note: this type is marked as 'beforefieldinit'.
		static ValueTypeNPrivateSealed1()
		{
			Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr = IL2CPP.GetIl2CppNestedType(Il2CppClassPointerStore<global::_PrivateImplementationDetails_>.NativeClassPtr, "__StaticArrayInitTypeSize=1535");
		}

		// Token: 0x0600039D RID: 925 RVA: 0x00003670 File Offset: 0x00001870
		public Object BoxIl2CppObject()
		{
			return new Object(IL2CPP.il2cpp_value_box(Il2CppClassPointerStore<global::_PrivateImplementationDetails_.ValueTypeNPrivateSealed1>.NativeClassPtr, ref this));
		}
	}
}
